package com.example.restaurent;

import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AlertDialogBox extends Activity implements OnClickListener{
    EditText e1;
    Button b1,b2;
    
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 final Dialog dialog=new Dialog(this);
		dialog.setContentView(R.layout.activity_alert_dialog_box);
		dialog.setTitle("Press Save to Place Order");
		e1=(EditText)dialog.findViewById(R.id.et1);
		b1=(Button)dialog.findViewById(R.id.dbutton1);
		b2=(Button)dialog.findViewById(R.id.dbutton2);
		dialog.show();
		 b1.setOnClickListener(new View.OnClickListener() {
             
             @Override
             public void onClick(View v) 
             {
            	 
               Toast.makeText(getApplicationContext(),"Order Saved",Toast.LENGTH_LONG).show();
              dialog.dismiss();
              Intent A=new Intent(getApplicationContext(),MenuItem.class);
              startActivity(A);
             }
     });
		 b2.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v)
			{
				dialog.dismiss();
			
			}
		 });
	
	
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.alert_dialog_box, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(v.getId()==b1.getId())
		{
			Toast.makeText(getApplicationContext(), "Inside click function",Toast.LENGTH_LONG).show();
		}
	}

	
		
	

}
