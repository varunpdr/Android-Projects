package com.example.restaurent;
import com.example.restaurent.*;
import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckedTextView;
import android.widget.ExpandableListView;
import android.widget.TextView;
import android.widget.Toast;

public class MenuItem extends ExpandableListActivity{

	// Create ArrayList to hold parent Items and Child Items
    private ArrayList<String> parentItems = new ArrayList<String>();
    private ArrayList<Object> childItems = new ArrayList<Object>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		ExpandableListView el=getExpandableListView();
		el.setDividerHeight(2);
		el.setGroupIndicator(null);
		el.setClickable(true);
		 setGroupParents();
         setChildData();
         MyExpandableAdapter adapter = new MyExpandableAdapter(parentItems, childItems);

         adapter.setInflater((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE), this);
         
         // Set the Adapter to expandableList
         el.setAdapter(adapter);
         el.setOnChildClickListener(this);
		
	}
    public void setGroupParents()
    {
    	parentItems.add("FastFood");
        parentItems.add("ColdStuff");
        parentItems.add("LunchFood");
        parentItems.add("Icecreams");
    }
    public void setChildData()
    {
    	ArrayList<String> child=new ArrayList<String>();
    	child.add("Pizza");
    	child.add("Munchrren Noodels");
    	child.add("Maggi");
    	child.add("French Fries");
    	child.add("Frankie");
    	child.add("Vada pav");
    	
    	childItems.add(child);
    	
    	child=new ArrayList<String>();
    	child.add("IceTea");
    	child.add("ColdCoffee");
    	child.add("Pepsi");
    	child.add("CocaCola");
    	child.add("Thumsup");
    	
    	childItems.add(child);
    	
    	child=new ArrayList<String>();
    	child.add("panner");
    	child.add("AlooMutter");
    	child.add("ShaiPanner");
    	child.add("pannerkofta");
    	child.add("DalFry");
    	childItems.add(child);
    	
    	child=new ArrayList<String>();
    	child.add("vanilla");
    	child.add("Butterscotch");
    	child.add("PistaCatchew");
    	child.add("Cream & Nuts");
    	childItems.add(child);
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_item, menu);
		return true;
	}

	class MyExpandableAdapter extends BaseExpandableListAdapter{

		private Activity activity;
	    private ArrayList<Object> childitems;
	    private LayoutInflater inflater;
	    private ArrayList<String> parentItems, child;
	    
	    public MyExpandableAdapter(ArrayList<String> parents,ArrayList<Object> children)
	    {
	    	this.parentItems=parents;
	    	this.childitems=children;
	    }
        
	    public void setInflater(LayoutInflater inflater, Activity activity) 
	    {
	        this.inflater = inflater;
	        this.activity = activity;
	    }
		@Override
		public Object getChild(int arg0, int arg1) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getChildId(int arg0, int arg1) {
			// TODO Auto-generated method stub
			return 0;
		}

		@SuppressWarnings("unchecked")
		@Override
		public View getChildView(int groupposition, final int childposition, boolean islastchild, View v,
				ViewGroup vg) {
			// TODO Auto-generated method stub
			child=(ArrayList<String>)childitems.get(groupposition);
			TextView tv=null;
			if(v==null)
			{
				v=inflater.inflate(R.layout.childview,null);
			}
			tv=(TextView)v.findViewById(R.id.textViewChild);
			tv.setText(child.get(childposition));
			v.setOnClickListener(new OnClickListener() {
				
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent A=new Intent(getApplicationContext(),AlertDialogBox.class);
					startActivity(A);
					
					///Toast.makeText(getApplicationContext(),child.get(childposition),Toast.LENGTH_LONG).show();
				}
			});
			
				
			
			/*v.setOnTouchListener(new OnTouchListener() {
				
				

				@Override
				public boolean onTouch(View arg0, MotionEvent arg1) {
					// TODO Auto-generated method stub
					Toast.makeText(getApplicationContext(),child.get(childposition),Toast.LENGTH_LONG).show();
					return true;
				}
			});
			*/
			return v;
		}

		@Override
		public int getChildrenCount(int groupposition) {
			// TODO Auto-generated method stub
			return ((ArrayList<String>) childItems.get(groupposition)).size();
		}

		@Override
		public Object getGroup(int arg0) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int getGroupCount() {
			// TODO Auto-generated method stub
			return parentItems.size();
		}

		@Override
		public long getGroupId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}
		 // method getGroupView is called automatically for each parent item
	    // Implement this method as per your requirement
		@Override
		public View getGroupView(int groupposition, boolean isExpanded, View v,
				ViewGroup vg) {
			// TODO Auto-generated method stub
			if(v==null)
			{
			  v=inflater.inflate(R.layout.parentview,null);	
			}
			((CheckedTextView)v).setText(parentItems.get(groupposition));
			((CheckedTextView)v).setChecked(isExpanded);
			return v;
		}

		@Override
		public void onGroupCollapsed(int groupPosition) {
			// TODO Auto-generated method stub
			super.onGroupCollapsed(groupPosition);
		}

		@Override
		public void onGroupExpanded(int groupPosition) {
			// TODO Auto-generated method stub
			super.onGroupExpanded(groupPosition);
		}

		@Override
		public boolean hasStableIds() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isChildSelectable(int arg0, int arg1) {
			// TODO Auto-generated method stub
			return false;
		}
		
	}
}
