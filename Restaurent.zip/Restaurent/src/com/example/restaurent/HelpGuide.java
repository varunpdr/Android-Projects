package com.example.restaurent;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;

public class HelpGuide extends Activity {
     TextView t1;
     
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_help_guide);
		t1=(TextView)findViewById(R.id.textView1);
	    t1.setText("HelpGuide:-\n"+"User should enter first infomation to visit menu page\n"+"On the Second page there are Options for\n"+"Menu,findstore,information,custmor,order\n"+"you can click on any one of these according to u..which will \n"+"lead u to the their corresponding functions\n"+"Menu Button includes menu for food\n"+"Order button is used for placing order\n"+"Using FindStore u can search nearby hotels"+"In infomation u can take help if u face a problem while processing\n"+"for more contact-7791940295");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.help_guide, menu);
		return true;
	}

}
