package com.example.restaurent;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.view.Menu;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
   ProgressBar pb;
   private int pstatus=0;
   private int size=0;
   private Handler ph=new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		pb=(ProgressBar)findViewById(R.id.progressBar1);
		pb.setClickable(true);
		pb.setActivated(true);
		pb.setHorizontalScrollBarEnabled(true);
		pb.setProgress(0);
		pb.setMax(100);
		
		Thread t=new Thread(){
			public void run()
			{ while(pstatus<100)
			{  pstatus=do_operation();
				try{
					 Thread.sleep(500);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				ph.post(new Runnable() {
					
					@Override
					public void run() {
						pb.setProgress(pstatus);
						
					}
				});
			}
			if(pstatus>=100)
			{
				try{
					Thread.sleep(100);
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			   
				Intent A=new Intent(getApplicationContext(),CustomerInfo.class);
				startActivity(A);
				/*finally{
					
					
				}*/
			}
			}
		};
		t.start();
		  
	}
	   public int do_operation(){
	    	while(size<10000)
	    	{
	    		size++;
	    		if(size==1000)
	    		{
	    			return 10;
	    		}
	    		if(size==2000)
	    		{
	    			return 20;
	    		}
	    		if(size==3000)
	    		{
	    			return 30;
	    		}
	    		if(size==4000)
	    		{
	    			return 40;
	    		}
	    		if(size==5000)
	    		{
	    			return 50;
	    		}
	    		if(size==6000)
	    		{
	    			return 60;
	    		}
	    		if(size==7000)
	    		{
	    			return 70;
	    		}
	    		if(size==8000)
	    		{
	    			return 80;
	    		}
	    		if(size==9000)
	    		{
	    			return 90;
	    		}
	    		if(size==10000)
	    		{
	    			return 100;
	    		}
	    		if(size>10000)
	    		{
	    			return 101;
	    		}
	    		
	    	}
	    	return 0;
	    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
		
	}

}
