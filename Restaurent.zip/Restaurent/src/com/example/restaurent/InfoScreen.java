package com.example.restaurent;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class InfoScreen extends Activity implements OnClickListener {
    TextView t1;
    Button b1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_info_screen);
		t1=(TextView)findViewById(R.id.textView1);
		t1.setText("This app  is an Restaurant App\n"+"Customer can Enter information in the home window\n"+"and can visit menus and can discover new restaurent\n"+"For more info click help button\n"+"copyright@by Varun");
		b1=(Button)findViewById(R.id.button1);
		b1.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.info_screen, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(b1.getId()==v.getId())
		{
		  Intent A=new Intent(getApplicationContext(),HelpGuide.class);
		  startActivity(A);
		  
		}
	}

}
