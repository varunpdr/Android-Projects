#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include<signal.h>
#define PORT "3490" //portn no through  which client will be connecting

#define MAXDATASIZE 100 // max number of char bytes that can be sent through client.

int score=0;//keep track of score of client on reciving "Y" or "N" from server.If Y ,score increments else remains unchange.
char b;
struct timeval timeout;
// This method return address 
void *get_in_addr(struct sockaddr *sa)
{
    if(sa->sa_family ==AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}
// This method checks whether recieved or sending bytes are equal to bytes we are trying to send or recieve
wrongRecv(ssize_t recvd, ssize_t expctd)
{

    if(recvd != expctd)
    {
        printf("Recvd(%zd) bytes not equal to expected(%zd) bytes\n",recvd,expctd);
        sleep(5);
          exit(0);
        getchar();
    }
   
}
//This method is used for calculating round trip time(rtt) for client server  by recieving and sending 1 byte.
void rtt_check(int sockfd)
{
    ssize_t send_ret, recv_ret;
    char rtt_check[1];
    recv_ret = recv(sockfd, rtt_check, 1,0);
    wrongRecv(recv_ret,1);
    sleep(1);//to check
    send_ret = send(sockfd, "r", 1, 0);
    wrongRecv(send_ret, 1);

    return;
}

int main(int argc, char *argv[])
{
    int sockfd, numbytes;  //socket discriptor for storing socket information
    char buf[MAXDATASIZE];
    char server[16];
    struct addrinfo hints, *servinfo, *p;
    int rv;
    char s[INET6_ADDRSTRLEN];
    printf("**************************************(MULTICLIENT- QUIZ- APP)*******************************************\n");
    printf("Enter server ip to join quiz:");
    scanf("%s",server);
    getchar();
    
    server[15]='\0'; 
    if(argc != 1) {
        fprintf(stderr,"usage: client hostname\n");
        exit(1);
    }
   
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
   /// getaddrinfo converts information from string or text to a struct of addrinfo and returns pointer servinfo of addrinfo.
  // creates dynamic linked list of struct addrinfo
    if((rv = getaddrinfo(server, PORT, &hints, &servinfo)) != 0) {
        fprintf(stderr,"getaddrinfo: %s\n",gai_strerror(rv));
        sleep(10);
        return 1;
    }

    //lopp through all the results of addrinfo of host information  and connect to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        if((sockfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1){
            perror("client: socket");
            continue;
        }

        if(connect(sockfd, p->ai_addr, p->ai_addrlen) == -1){
            close(sockfd);
            perror("client: connect");
            continue;
        }

        break;
    }

    if(p ==NULL) {
        fprintf(stderr,"client: failed to connect\n");
        sleep(10);
        return 2;
    }

    inet_ntop(p->ai_family, get_in_addr((struct sockaddr *)p->ai_addr), s, sizeof s);  //converts from binary numeric address into string 	     
     printf("client connecting to %s\n",server);
     char login_det[8],ch;
     time_t start,end;
     start=time(NULL); 
     printf("Enter_your_nickname(upto 7 chars)\n");
     scanf("%s",login_det);
     
     while ((ch = getchar()) != '\n' && ch != EOF); 
     end=time(NULL);
     if((end-start)>10)
{    printf("You are too late!! quiz is  not available now\n");
     fflush(stdout);
     sleep(10);
      exit(0);
}
    //  getchar();
      freeaddrinfo(servinfo); //free the  memory of structure allocated by getaddrinfo function above.
      char login_retMsg[7], login_stat[3], totalQuesMsg[5];
      int totalQues;

    //sending login details
    ssize_t send_ret,recv_ret;
    send_ret = send(sockfd, login_det,8,0);
    wrongRecv(send_ret,8);
   fd_set read_fds;
    //receiving login status
    recv_ret = recv(sockfd,login_retMsg,7,0);
    wrongRecv(recv_ret,7);

    strncpy(login_stat, login_retMsg, 2);
    login_stat[2] = '\0';
    printf("Login Status(%s)\n",login_stat);
    strncpy(totalQuesMsg, login_retMsg + 2, 5);
    totalQues = atoi(totalQuesMsg);
    printf("totalQues(%d)\n",totalQues);
    printf("**************************  wait for quiz to start *****************************\n");
    if(!strcmp(login_stat,"OK")) {  //login ok
        char quesId[5];
        int maxQues_Len = 40, maxOpt_len = 10, maxQuesId_len = 5;//including '\0' this time
        char quesMsg[85], scoreMsg[1];//score doesnot include \0
        char ques[40], optA[10], optB[10], optC[10], optD[10];
        char answer[6];

        while(totalQues--) {
            //checking rtt
            rtt_check(sockfd);
            //receving question from server in char array quesMsg[85]
            recv_ret = recv(sockfd, quesMsg,  maxQues_Len + 4 * maxOpt_len + maxQuesId_len ,0);
            wrongRecv(recv_ret,  maxQues_Len + 4 * maxOpt_len + maxQuesId_len);
            strncpy(quesId,quesMsg,5);
            strncpy(ques, quesMsg + 5, 40);
            strncpy(optA, quesMsg + 45, 10);
            strncpy(optB, quesMsg + 55, 10);
            strncpy(optC, quesMsg + 65, 10);
            strncpy(optD, quesMsg + 75, 10);
            printf("QUESID(%s) (Question)%s\n(A)%s\n(B)%s\n(C)%s\n(D)%s\n",quesId,ques,optA,optB,optC,optD);
            timeout.tv_sec =4;    //time set for answer timeout
            timeout.tv_usec = 0;
             FD_SET(0,&read_fds);

           int ready;
            if (select(1, &read_fds, NULL, NULL, &timeout))
            {   scanf("%c",&b);
                getchar();
                printf("%s\n","Answer Message Sent" );
            }
           else
           {
             b='x';
             printf("Timeout occured\n");
           }  
            strncpy(answer,quesId, 5);
            answer[5] = b;
            sleep(5);
            send_ret = send(sockfd,answer,6,0);//sending answer(question id && option selected) to server
            wrongRecv(send_ret,6);
           
           b='x';
           char sc[1];
           recv_ret=recv(sockfd,sc,1,0);
 	   if(recv_ret==1 && sc[0]=='Y')
		{
                 printf("your score is %d\n",(++score));
		}	
		else{
	        	 printf("your score is %d\n",score);
	            }
        
            sleep(5);
          
 } 
   printf("************************************  Thanks For Participation *********************************\n");
   printf("Quiz ends!!\n");
   char winner[11][9];
   int c;
   int count=recv(sockfd,&c,4,0); //receving number of winners in the quiz
   int by= recv(sockfd,winner,99,0); 
   int i;
   for(i=0;i<c;i++)    //printing all the values of winners in the quiz
    { 
   printf("winner of quiz is: %s\n",winner[i]);
     }
  sleep(10);
   close(sockfd);

    return 0;
}
}
