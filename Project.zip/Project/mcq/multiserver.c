#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <error.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#define PORT "3490" //the port user will be connecting to
#define BACKLOG 10  //maximum  pending connection that a queue can hold
//#define maxUser 10 //maximum users for quizz.
#define LOGIN_OK "OK" 
#define MAX_USERS 10
#define MAX_ANSWER_TIME 10
#define LOGIN_WAIT 20
#define TOTAL_QUES "3"
int flag=0;
int cur_num=0;
int u_id=0;
int counter=0;
char user_name[11][9];//array to store nicknames of all clients.

//extern void FD_COPY(const restrict( fd_set*From),const restrict fd_set *to);
int users[MAX_USERS][3] = {};  //index is userID, 0 is no user


int timer;
void alarm_handler(int s) {
    timer = 0;
}

wrongRecv(ssize_t recvd, ssize_t expctd)
{

    if(recvd != expctd)
    {
        printf("Recvd(%zd) bytes not equal to expected(%zd) bytes\n",recvd,expctd);
        //getchar();
    }
}

//void nextQues(char* quesMsg, char* ques, char* optA, char* optB, char* optC, char* optD)
int nextQues(char* quesMsg, int QID)
{
    char ques[40], optA[10], optB[10], optC[10], optD[10], quesId[5];
    //char temp=QID;
   //strncpy(quesId,&temp,5);
    sprintf(quesId,"%d",QID);
   
    if(flag==0)
   { strncpy(ques,"What is capital of india?",40);
    strncpy(optA,"Delhi",10);    strncpy(optB,"Mumbai",10);    strncpy(optC,"Jaipur",10); strncpy(optD,"Ahmd",10);
   
  }
  else if(flag==1)
  {
    strncpy(ques,"Who is captain of Indian cricket team?",40);
    strncpy(optA,"kohli",10);   strncpy(optB,"MSDhoni",10);   strncpy(optC,"S_Raina",10); strncpy(optD,"R_Jadeja",10);
  
  }
 else
 {
    strncpy(ques,"Who is PM of INDIA in 2014?",40);
   strncpy(optA,"M.Singh",10); strncpy(optB,"R.Gandhi",10); strncpy(optC,"N.Modi ",10);  strncpy(optD,"Sonia.G",10);
   
 }
    strncpy(quesMsg,quesId,5);
    strncpy(quesMsg + 05,ques,40);
    strncpy(quesMsg + 45,optA,10);
    strncpy(quesMsg + 55,optB,10);
    strncpy(quesMsg + 65,optC,10);
    strncpy(quesMsg + 75,optD,10);
    

    return 0;
}

//void answerCheck(char* ques, char* optA, char* optB, char* optC, char* optD, char* usrResponse, int rtt, int timeTaken)
void answerCheck(int fd, char usrResponse[6], int rtt, int timeTaken)
{
    int responseTime, i;
    char actualAnswer[3];
    char quesId[5];
    printf("fd(%d) quesid(%s) response(%c) rtt(%d) timeTaken(%d)\n", fd, usrResponse, usrResponse[5], rtt, timeTaken );
    strncpy(quesId, usrResponse, 5);
    actualAnswer[0] ='A';//we have quesId we can find actual answer on basis of it
    actualAnswer[1]='B';
    actualAnswer[2]='C';   
    if(actualAnswer[flag-1] == usrResponse[5])
    {
        //printf("%s\n","+++++" );
        responseTime = timeTaken - rtt;
        //printf("Response Time(%d)\n",responseTime);
        //save it with user id

        //finding userid
        for(i = 0; i < MAX_USERS; i++) {
            if(users[i][1] == fd) {
                users[i][2] = responseTime;//saving it
                //printf("%d\n",i );
            }
        }
    }
   else{     for(i = 0; i < MAX_USERS; i++) {
            if(users[i][1] == fd) {
                users[i][2] =0;//saving it
                //printf("%d\n",i );
                 }
       }
    
}
}
int compareAnswer() {
    int i, min = 2 * MAX_ANSWER_TIME, userIndex=-1;
    for(i = 0; i < MAX_USERS; i++) {
        if(users[i][2] < min && users[i][2]>0 && users[i][1]!=0) {
            min = users[i][2];
            userIndex = i;
            users[i][2]==0;
        }
    }
    //Increasing Score
   users[userIndex][0]++;
//  printf("winner is %d",users[userIndex][1]);
    //returning fd
    return userIndex;
		   }

void users_deleteFd(int fd) {
    int i;
    for (i = 0; i < MAX_USERS; ++i)
    {
        if(users[i][1] == fd) {
            users[i][1] =0;
            return;
        }
    }
}

int rtt_check(int new_fd)
{
    ssize_t send_ret, recv_ret;
    char rtt_check[1];
    time_t rtt1, rtt2;

    rtt1 = time(NULL);
    //printf("hye");
    send_ret = send(new_fd, "r", 1, 0);
   // printf("bye");
    if(send_ret <= 0)
    {
        return -2;
    }
    wrongRecv(send_ret, 1);
    //printf("%s\n","Between two phase of rttCheck" );
    recv_ret = recv(new_fd, rtt_check, 1,0);
    
    rtt2 = time(NULL);
    if(recv_ret == 0)
    {
        return -2;
    }
    wrongRecv(recv_ret,1);
    //printf("diff(%d)\n",(int) difftime(rtt2,rtt1));

    return  (int) difftime(rtt2,rtt1);
}

int totalQues;

int login_setup(int new_fd)
{
    //login inititalizations
    char login_det[8];
    char username[9],login_statMsg[7], totalQuesMsg[5] = TOTAL_QUES;
    totalQues = atoi(totalQuesMsg);//converts char value to integer value.
    //for user
    static int userId=0;

    //for wrongRecv
    ssize_t send_ret,recv_ret;

    //getting username and password
    recv_ret = recv(new_fd,login_det,8,0);
    if(recv_ret == 0)
    {
        return -2;
    }
    wrongRecv(recv_ret,8);
    strncpy(user_name[++u_id],login_det,8);       
    strncpy(login_statMsg, LOGIN_OK, 2);
    strncpy(login_statMsg + 2, totalQuesMsg , 5);
    send_ret = send(new_fd,login_statMsg,7,0);
    if(send_ret == 0)
        {
            return -2;
        }
        wrongRecv(send_ret,7);

        //TODO error checking then handling if error

        //users[userId][0] = 0; //score
        users[++userId][1] = new_fd; //file descriptor associated with this user
        //users[userId][2] = 0; //answer time
        return 1;
   
}


void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}


int main(void)
{
    int listen_fd, new_fd; // listen on sock_fd, new connection on new_fd
    struct addrinfo hints, *servinfo, *p;
    struct sockaddr_storage their_addr;//connection's address info
    socklen_t sin_size;
    int yes=1;
    char s[INET6_ADDRSTRLEN];
    int rv;

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;//IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE; // use my IP

    if((rv = getaddrinfo(NULL,PORT, &hints, &servinfo)) != 0){ //getting which IPv server supports
        fprintf(stderr, "getaddrinfo: %s\n",gai_strerror(rv));
        return 1;
    }

    //loop through all the result and bind to the first we can
    for(p = servinfo; p != NULL; p  = p->ai_next){
        if((listen_fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1){
            perror("server : socket");
            continue;
        }

        if(setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1){
            perror("set sockopt");
            exit(1);
        }

        if(bind(listen_fd, p->ai_addr, p->ai_addrlen) == -1){
           close(listen_fd);
            perror("server: bind");
            continue;
        }

        break;
    }

    if(p == NULL) {
        fprintf(stderr, "server:failed to bind\n");
        return 2;
    }

    freeaddrinfo(servinfo);//all done with this structure

    if(listen(listen_fd, BACKLOG) == -1){
        perror("listen");
        exit(1);
    }

    printf("server waiting for connections.....\n");

    fd_set master; //master file descriptor list
    fd_set read_fds; //temp file descriptor list for select()
    int fdmax;
    FD_ZERO(&master); //clear the master and temp sets
    FD_ZERO(&read_fds);

    FD_SET(listen_fd, &master);//setting listen_fd value in master file descriptor
    //keep track of the bigge file descriptor
    FD_SET(listen_fd,&read_fds);
    fdmax = listen_fd; // so far it is this one
       
    ssize_t recv_ret, send_ret;


    //for login
    int loginStatus;
    struct sigaction sa;  //defined in "#include<signal.h>"
    sa.sa_handler = alarm_handler;
    sigemptyset(&sa.sa_mask);//intializes a signal mask to exclude all signals
    //sa.sa_flags = SA_RESTART;
    if(sigaction(SIGALRM, &sa, NULL) == -1){ //runs when signal is caught
        perror("sigaction");
        exit(1);
    }


    //login while
    alarm(LOGIN_WAIT);//accepting login only for 20 seconds
    timer = 1;
    //it helps in running while loop until an alarm signal interrupt arrives.
    printf("\n-----------------------------Waiting for users to login for %d seconds.-----------------------------\n",LOGIN_WAIT);
    while(timer) {
        sin_size = sizeof their_addr;
        new_fd = accept(listen_fd, (struct sockaddr *)&their_addr, &sin_size);
        if(new_fd == -1){
            //perror("accept");
            break;// this break is very important , as we are using alarm(Signals) and accept is a blocking function
                    
        }else {

            inet_ntop(their_addr.ss_family, get_in_addr((struct sockaddr *)&their_addr), s, sizeof s);
            printf("server : got connection from user %s\n", s);     
            sleep(4);
            loginStatus = login_setup(new_fd);
                             
            //adding to select checkup
           if(loginStatus) {
                printf("User Loginned Succesfully\n");
                           }
        }
    } 
    

    printf("-----------------------------Login Closed. Now starting the QUIZ.-----------------------------\n");
    printf("-------------------------------------Best Of Luck!!!------------------------------------------\n");
    //for randome seek
    srand(time(NULL));

    //for main loop counter
    int i, win_fd;

    //for questions
    int QID = 0;
    int maxQues_Len = 40, maxOpt_len = 10, maxQuesId_len = 5;//including '\0' this time
    char quesMsg[85], answer[6];//score doesnot include \0
    //char ques[40], optA[10], optB[10], optC[10], optD[10];

    //for time calculation of each answer
    ssize_t time_ques, time_ans;

    //getting all avialable participants
    fdmax = 0;
    FD_ZERO(&master);
    for(i = 0; i < MAX_USERS; i++) {
        if( (new_fd = users[i][1]) != 0){
            FD_SET(new_fd, &master);//storing fds in master fd set
            if(new_fd > fdmax)
                fdmax = new_fd;
    //        printf("%d\n",new_fd);
        }
    }
   /// printf("hahahahaa");
    int current_rtt;
    //while for main quiz
    while(totalQues--) {
  
        //checking who are ready for witing
        if(select(fdmax+1, NULL, &master, NULL, NULL) ==-1){//here select will return withh all the descriptors which are 
                                                                //ready to write , all others have to miss this question
            perror("select");
            exit(0);
        }
        	
        //setting which question to send
        QID++;

        //for sending questions to all
        for(i = 0; i <= fdmax; i++) {
            if(FD_ISSET(i, &master)) {
                //rtt check
                current_rtt = rtt_check(i);
                if(current_rtt == -2) {//connection closed
                    FD_CLR(i, &master);
                    users_deleteFd(i);
                    close(users[i][1]);
                    continue;
                }
                //setting question
                //nextQues(quesMsg, ques, optA, optB, optC, optD);
                nextQues(quesMsg, QID);
                printf("Sending Question QID(%s) fd(%d)\n",quesMsg,i);
                //send a question
                time_ques = time(NULL);
                send_ret = send(i, quesMsg, maxQues_Len + 4 * maxOpt_len + maxQuesId_len, 0);
                if(send_ret == 0) {//connection closed
                    FD_CLR(i, &master);
                    users_deleteFd(i);
                    continue;
                }
                wrongRecv(send_ret, maxQues_Len + 4 * maxOpt_len + maxQuesId_len); 
               
            }
        }
        
        //ASSUMING Question is send ot all the users at same time       
        //receiving and waiting for answers
        alarm(MAX_ANSWER_TIME);
        timer = 1;
      counter++;
       flag++;
       signal(SIGALRM,alarm_handler);
	FD_ZERO(&read_fds);
    int k;
    
  
       read_fds=master;
        
        while(timer) {
            read_fds=master;

              int val=0;
            
            if((val=select(fdmax+1, &read_fds,NULL, NULL,NULL))==-1)//when signal arrives select returns immediately.
       	    {    perror("select");
   		  // printf("Sorry! you are in trap\n");
                   
                break;
            }
           printf("fd availabe %d",val);
            for(i = 0; i <=MAX_USERS; i++) {
                //printf("Recving answer I(%d)\n",i);
               	    if(FD_ISSET(users[i][1],&read_fds)) {
                    //receiving answer
                     
                    //TODO if we get answer to wrong ques
    	          	                
                    printf("Recving answer I(%d) fdmax (%d)\n",users[i][1],fdmax);
                    recv_ret = recv(users[i][1],answer,6,0);
                    time_ans = time(NULL);
                    wrongRecv(recv_ret,6);
                    printf("%s %c\n",answer,answer[5]);
                       fflush(stdout);
                    if(recv_ret == 0)//connection closed
                    {   if(counter==3)
		 	{ printf("hello where r u going");
                          exit(0);
                        }
			printf("%d disconnected\n",users[i][1]);
                        FD_CLR(users[i][1], &read_fds);
                       FD_CLR(users[i][1],&master);
                       // users_deleteFd(users[i][1]);
                        continue;
                    }else if(recv_ret > 0){
                        if(QID == atoi(answer)) { //we have received the answer to this question so remove the user from wait answer loop
                            FD_CLR(users[i][1], &read_fds);
                            //printf("%s i(%d)\n","#######",i );
                            answerCheck(users[i][1] ,answer, current_rtt, (int) difftime(time_ans,time_ques));
                          
                            
                        }
                        else{
                            sleep(2);
                            exit(0);         
                        }
                    }

                    //time_t cccc = time(NULL);
                    //printf("%s I(%d)\n",ctime(&cccc),i);
                }
            }
          }
                  
        int j,win_id;
        win_id = compareAnswer();
     //   printf("winner id is%d\n",win_id);
       for(j=0;j<MAX_USERS;j++)
       {  if(FD_ISSET(users[j][1],&master))
         {
         if(win_id!=j)
        send(users[j][1],"N",1,0);
         else
           send(users[win_id][1],"Y",1,0);
         }
       // printf("winning fd for this ques is %d\n",win_fd);
        //sending score for each question to reciever
       }
                      if(counter==3)
                     {
                          int p=0;
                          int max=0;
                          int w;
                          for(p=1;p<MAX_USERS;p++)
                           {
                            if(FD_ISSET(users[p][1],&master))
                               {
                                  if(users[p][0]>max)
                                     { max=users[p][0];
                                        w=p;
                                      }
                               }
                           }
                            char winners[11][9];
                           int  size=0;
                            for(p=1;p<=MAX_USERS;p++)
                           {
                            if(FD_ISSET(users[p][1],&master))
                               {
                                  if(max==users[p][0])
                                   {  strncpy(winners[size],user_name[p],8);
                                      winners[size++][8]='\0';
                             	       printf("winner:%s && score :%d\n",user_name[p],max);
                                   }
                                 
                               }
                           }
                         int count=size;
                       //  printf("winner:%s && score :%d\n",user_name[w],max);
                          size=size*9;       
                      for(p=1;p<MAX_USERS;p++)
                           {   
              
                            if(FD_ISSET(users[p][1],&master))
                               {
				  send(users[p][1],&count,4,0);
                                   send(users[p][1],winners,size,0);

                               }
                           }
                        sleep(10);
                        exit(0);
                      } 
    }
   sleep(10);
   return 0;
}

