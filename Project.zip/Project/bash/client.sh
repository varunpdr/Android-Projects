#!/bin/bash
gcc multiclient.c -o mclient
./mclient
