#!/bin/bash
gcc multiserver.c -o mserver
./mserver
